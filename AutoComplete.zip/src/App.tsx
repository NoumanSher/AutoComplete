import React from "react";
import AutoCompletes from "./components/AutoComplete/AutoComplete";
import { countries } from "./mocks/data";

function App() {
  return (
    <div className="App">
      <AutoCompletes
        id="autoComplete"
        options={countries}
        onChange={(value: any) => {
          console.log(value);
        }}
      />
    </div>
  );
}

export default App;
