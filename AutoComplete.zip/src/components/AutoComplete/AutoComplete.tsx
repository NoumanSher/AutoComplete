import React, { Component } from "react";
import "./style.css";
interface IAutocompleteProps {
  options: string[];
  id: string;
  onChange: (e: any) => void;
}

interface IAutocompleteState {
  activeSuggestion: number;
  filteredOptions: string[];
  showOptions: boolean;
  userInput: string;
}

class Autocomplete extends Component<IAutocompleteProps, IAutocompleteState> {


  constructor(props: any) {
    super(props);

    this.state = {
      activeSuggestion: 0,
      filteredOptions: [],
      showOptions: false,
      userInput: "",
    };
  }

  onChange = (e: any) => {
    const { options } = this.props;
    const userInput = e.currentTarget.value;

    const filteredOptions = options.filter(
      (suggestion) =>
        suggestion.toLowerCase().indexOf(userInput.toLowerCase()) > -1
    );

    this.setState({
      activeSuggestion: 0,
      filteredOptions,
      showOptions: true,
      userInput: e.currentTarget.value,
    });
  };

  onClick = (e: any) => {
    this.setState({
      activeSuggestion: 0,
      filteredOptions: [],
      showOptions: false,
      userInput: e.currentTarget.innerText,
    });
  };

  onKeyDown = (e: any) => {
    const { activeSuggestion, filteredOptions } = this.state;

    // User pressed the enter key
    if (e.keyCode === 13) {
      this.setState({
        activeSuggestion: 0,
        showOptions: false,
        userInput: filteredOptions[activeSuggestion],
      });
    }
    // User pressed the up arrow
    else if (e.keyCode === 38) {
      if (activeSuggestion === 0) {
        return;
      }

      this.setState({ activeSuggestion: activeSuggestion - 1 });
    }
    // User pressed the down arrow
    else if (e.keyCode === 40) {
      if (activeSuggestion - 1 === filteredOptions.length) {
        return;
      }

      this.setState({ activeSuggestion: activeSuggestion + 1 });
    }
  };

  render() {
    const {
      onChange,
      onClick,
      onKeyDown,
      state: { activeSuggestion, filteredOptions, showOptions, userInput },
    } = this;

    let OptionsListComponent;

    if (showOptions && userInput) {
      if (filteredOptions.length) {
        OptionsListComponent = (
          <ul className="Options">
            {filteredOptions.map((suggestion: any, index: number) => {
              let className;

              if (index === activeSuggestion) {
                className = "suggestion-active";
              }

              return (
                <li className={className} key={suggestion} onClick={onClick}>
                  {suggestion}
                </li>
              );
            })}
          </ul>
        );
      } else {
        OptionsListComponent = (
          <div className="no-Options">
            <em>No Options, you're on your own!</em>
          </div>
        );
      }
    }

    return (
      <div className="autoComplete">
        <h3 style={{textAlign:"center"}}>Nouman sher khan</h3>
        <h3>Autocomplete</h3>
        <p> start typing</p>
        <input
          type="text"
          onChange={onChange}
          onKeyDown={onKeyDown}
          placeholder="Country"
          value={userInput}
        />
        <input className="button" type="submit"/>
        {OptionsListComponent}
      </div>
    );
  }
}

export default Autocomplete;
